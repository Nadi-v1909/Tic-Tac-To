package tiktacto.Login;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TicTakToApp extends JFrame {
    
    final public static int UNASSIGNED = 0;
    final public static int PLAYER = 1;
    final public static int ROBOT = 2;
    final public static int TIE = 3;
    
    final public static int GRID_WIDTH = 3;
    final public static int GRID_HEIGHT = 3;
    
    JPanel tilePanel;
    JPanel layoutPanel;
    JPanel topPanel;
    JPanel bottomPanel;
    
    JButton tiles[][] = {
        {new JButton(), new JButton(), new JButton()},
        {new JButton(), new JButton(), new JButton()},
        {new JButton(), new JButton(), new JButton()}
    };
    
    public int[][] value = {
        {UNASSIGNED, UNASSIGNED, UNASSIGNED},
        {UNASSIGNED, UNASSIGNED, UNASSIGNED},
        {UNASSIGNED, UNASSIGNED, UNASSIGNED}
    };
    private int currentPlayer = PLAYER;
    
    public void run() {
        
        gui();
        System.out.println("Winner is: " + checkWinner());
        updateTile(value);
    }
    
    public int checkWinner() {
        
        if (checkPlayerWinner(PLAYER) == PLAYER) {
            return PLAYER;
        }
        if (checkPlayerWinner(ROBOT) == ROBOT) {
            return ROBOT;
        }
        
        for (int i = 0; i < value.length; i++) {
            for (int j = 0; j < value[i].length; j++) {
                
                if (value[i][j] == UNASSIGNED) {
                    return UNASSIGNED;
                }
            }
        }
        
        return TIE;
    }
    
    public int checkPlayerWinner(int player) {

        //Horizontal
        if (value[0][0] == player
                && value[0][1] == player
                && value[0][2] == player) {
            
            return player;
        }
        
        if (value[1][0] == player
                && value[1][1] == player
                && value[1][2] == player) {
            
            return player;
        }
        
        if (value[2][0] == player
                && value[2][1] == player
                && value[2][2] == player) {
            
            return player;
        }
        //Vertical  

        if (value[0][0] == player
                && value[1][0] == player
                && value[2][0] == player) {
            
            return player;
            
        }
        
        if (value[0][1] == player
                && value[1][1] == player
                && value[2][1] == player) {
            
            return player;
        }
        
        if (value[0][2] == player
                && value[1][2] == player
                && value[2][2] == player) {
            
            return player;
        }

        //Diagonal
        if (value[0][2] == player
                && value[1][1] == player
                && value[2][0] == player) {
            
            return player;
        }
        
        if (value[0][0] == player
                && value[1][1] == player
                && value[2][2] == player) {
            return player;
        }
        return UNASSIGNED;
    }
    
    public void playGame() {
        
        if (Math.random() > 0.5) {
            currentPlayer = PLAYER;
        } else {
            currentPlayer = ROBOT;
        }
        
    }

//add play method(takes i and j as input)
    public void playTile(int i, int j) {
        
        if (value[i][j] != UNASSIGNED) {
            return;
        }
        //update value of i and j
        this.value[i][j] = currentPlayer;
        //assign next player
        if (currentPlayer == PLAYER) {
            currentPlayer = ROBOT;
        } else {
            currentPlayer = PLAYER;
        }
        //call update tile with new values
        updateTile(value);
        int answer = checkWinner();
        if (answer != UNASSIGNED) {
            System.out.println("Winner is " + answer);
            
        }
    }
    
    public void updateTile(int[][] value) {
        for (int i = 0; i < value.length; i++) {
            for (int j = 0; j < value[i].length; j++) {
                if (value[i][j] == TicTakToApp.UNASSIGNED) {
                    this.tiles[i][j].setText("");
                    
                } else if (value[i][j] == TicTakToApp.PLAYER) {
                    this.tiles[i][j].setText("X");
                } else {
                    this.tiles[i][j].setText("O");
                }
            }
        }
    }
    
    public void gui() {

        //calling JFrame constructor
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(533, 284, 300, 400);
        setVisible(true);
        
        Font tileFont = new Font(Font.SERIF, Font.BOLD, 63);
        
        GridLayout tileLayout = new GridLayout(3, 3);
        tilePanel = new JPanel(tileLayout);
        
        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                
                tiles[i][j].setFont(tileFont);
                tiles[i][j].setHorizontalAlignment(JLabel.CENTER);
                
                tiles[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        for (int i = 0; i < tiles.length; i++) {
                            for (int j = 0; j < tiles[i].length; j++) {
                                if (e.getSource() == tiles[i][j]) {
                                    playTile(i, j);
                                }
                            }
                        }
                    }
                });
                tilePanel.add(tiles[i][j]);

                layoutPanel = new JPanel();
                topPanel = new JPanel();
                bottomPanel = new JPanel();
                
                layoutPanel.add(tilePanel, BorderLayout.CENTER);
                layoutPanel.add(topPanel, BorderLayout.NORTH);
                layoutPanel.add(bottomPanel, BorderLayout.SOUTH);
                
                
            }
            
        }
        add(tilePanel);
        setVisible(true);
        
    }
}
