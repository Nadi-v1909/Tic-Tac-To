
package tiktacto;

import tiktacto.Login.TicTakToApp;


public class Main {

    
    public static void main(String[] args) {
        
        TicTakToApp app = new TicTakToApp();
        
            app.run();    
        
    }
    
}
